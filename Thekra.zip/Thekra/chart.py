import streamlit as st # type: ignore
import pandas as pd # type: ignore
import plotly.express as px # type: ignore

# إعداد الصفحة في Streamlit
st.set_page_config(page_title="Renewable Energy Consumption Tracker", layout="wide")

# عنوان التطبيق
st.title("📊 Renewable Energy Consumption Tracker")
st.markdown("### تصور بياني لاستهلاك الطاقة المتجددة حسب الأشهر")

# بيانات تجريبية
data = {
    "Month": ["January", "February", "March", "April", "May", "June"],
    "Energy Consumption (MWh)": [400, 380, 420, 460, 480, 500]
}
df = pd.DataFrame(data)

# إنشاء Column Chart باستخدام Plotly
fig = px.bar(df, x="Month", y="Energy Consumption (MWh)", 
             title="استهلاك الطاقة المتجددة حسب الأشهر",
             color="Energy Consumption (MWh)", 
             color_continuous_scale="Viridis")

# تحسين المظهر
fig.update_layout(
    xaxis_title="الشهر",
    yaxis_title="استهلاك الطاقة (MWh)",
    template="plotly_dark"
)

# عرض المخطط في Streamlit
st.plotly_chart(fig, use_container_width=True)
